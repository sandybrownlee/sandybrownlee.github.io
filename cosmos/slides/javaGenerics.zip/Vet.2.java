import animals.*;
import java.util.*;

public class Vet extends Human {

    // <editor-fold defaultstate="collapsed" desc="/* Constructor Goes Here */">
    public Vet(String name) {
        super(name);
    }
    public Vet(String name, boolean healthy) {
        super(name, healthy);
    }
    // </editor-fold>

    // Check an animal
    public void check(Animal animal) {
        // <editor-fold defaultstate="collapsed" desc="/* Logic Goes Here */">
        System.out.println(getName() + " says "
                + animal.getName() + " is "
                + (animal.isHealthy() ? "healthy" : "sick"));
        try {
            Thread.sleep(10L);
        } catch (InterruptedException ex) {}
        // </editor-fold>
    }
    
    // Check multiple animals (array)
    public final void check(Animal[] animals) {
        for (Animal a : animals) {
            check(a);
        }
    }
    
    // Check multple animals (collection)
    public final void check(Collection<? extends Animal> animals) {
        for (Animal a : animals) {
            check(a);
        }
    }

    // Hospitalise sick animals
    public final <T extends Animal> void move(
            Collection<T> animals,
            Collection<? super T> hospital) {
        for (T a : animals) {
            if (!a.isHealthy()) {
                System.out.println("Moving " + a.getName());
                hospital.add(a);
            }
        }
    }
    
    public static void main(String[] args) {
        
        Vet drNick = new Vet("Dr. Nick");
        
        Cat nyanCat = new Cat("Nyan Cat");
        Cat grumpyCat = new Cat("Grumpy Cat", false);
        
        Cat[] array = new Cat[] {nyanCat, grumpyCat};
        
        System.out.println("Checking Array . . .");
        drNick.check(array);
        System.out.println();

        List<Cat> list = new LinkedList<>();
        list.add(nyanCat);
        list.add(grumpyCat);
        
        System.out.println("Checking List . . .");
        drNick.check(list);
        System.out.println();

        List<Animal> hospital = new LinkedList<>();
        System.out.println("Moving Sick . . .");
        drNick.move(list, hospital);

    }
    
}
