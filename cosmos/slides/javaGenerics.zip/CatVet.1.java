package further;

import animals.*;

public class CatVet extends Vet<Cat> {
    
    public CatVet(String name) {
        super(name);
    }
    
    public void check(Cat cat) {
        super.check(cat);
        cat.meow(); // cat specific code
    }
    
    public static void main(String[] args) {
        Cat[] cats = new Cat[] {new Cat("Nyan Cat")};
        Vet<Cat> catVet = new CatVet("Dr. Nick");
        catVet.check(cats);
    }
    
}
