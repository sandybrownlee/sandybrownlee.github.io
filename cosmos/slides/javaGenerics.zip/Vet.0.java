import animals.*;
import java.util.*;

public class Vet extends Human {

    // <editor-fold defaultstate="collapsed" desc="/* Constructor Goes Here */">
    public Vet(String name) {
        super(name);
    }
    public Vet(String name, boolean healthy) {
        super(name, healthy);
    }
    // </editor-fold>

    // Check an animal
    public void check(Animal animal) {
        // <editor-fold defaultstate="collapsed" desc="/* Logic Goes Here */">
        System.out.println(getName() + " says "
                + animal.getName() + " is "
                + (animal.isHealthy() ? "healthy" : "sick"));
        try {
            Thread.sleep(10L);
        } catch (InterruptedException ex) {}
        // </editor-fold>
    }
    
    // Check multiple animals (array)
    public final void check(Animal[] animals) {
        for (Animal a : animals) {
            check(a);
        }
    }
    
    // Check multple animals (collection)
    public final void check(Collection animals) {
        for (Object a : animals) {
            check((Animal) a);
        }
    }
    
    public static void main(String[] args) {
        
        Vet drNick = new Vet("Dr. Nick");
        
        Cat nyanCat = new Cat("Nyan Cat");
        Cat grumpyCat = new Cat("Grumpy Cat", false);
        Integer bestNumber = Integer.valueOf(42);
        
        Animal[] array = new Animal[] {nyanCat, grumpyCat};
        
        System.out.println("Checking Array . . .");
        drNick.check(array);
        System.out.println();

        List list = new LinkedList();
        list.add(nyanCat);
        list.add(grumpyCat);
        list.add(bestNumber);
        
        System.out.println("Checking List . . .");
        drNick.check(list);
        System.out.println();

    }
    
}
