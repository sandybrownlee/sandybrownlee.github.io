package animals;

public class Animal {
    
    private boolean healthy = true;
    private String name;
    
    public Animal(String name) {
        this(name, true);
    }
    
    public Animal(String name, boolean healthy) {
        this.name = name;
        this.healthy = healthy;
    }
    
    public final boolean isHealthy() {
        return healthy;
    }
    
    public final void setHealthy(boolean healthy) {
        this.healthy = healthy;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    @Override
    public String toString() {
        return getClass().getSimpleName()
                + "(name=" + getName() + ", healthy=" + isHealthy() + ")";
    }
    
}
