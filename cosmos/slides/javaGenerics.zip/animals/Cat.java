package animals;

public class Cat extends Mammal {
    
    public Cat(String name) {
        super(name);
    }
    
    public Cat(String name, boolean healthy) {
        super(name, healthy);
    }
    
    public void meow() {
        System.out.println(getName() + " meows.");
    }
    
}
