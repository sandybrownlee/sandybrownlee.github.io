package animals;

public class Human extends Mammal {
    
    public Human(String name) {
        super(name);
    }
    
    public Human(String name, boolean healthy) {
        super(name, healthy);
    }
    
}
