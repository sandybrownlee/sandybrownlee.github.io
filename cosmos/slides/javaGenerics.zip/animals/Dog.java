package animals;

public class Dog extends Mammal {
    
    public Dog(String name) {
        super(name);
    }
    
    public Dog(String name, boolean healthy) {
        super(name, healthy);
    }
    
}
