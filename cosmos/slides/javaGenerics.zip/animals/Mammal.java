package animals;

public class Mammal extends Animal {
    
    public Mammal(String name) {
        super(name);
    }
    
    public Mammal(String name, boolean healthy) {
        super(name, healthy);
    }
    
}
