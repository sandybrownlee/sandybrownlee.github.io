import animals.*;

public class CatVet extends Vet {
    
    public CatVet(String name) {
        super(name);
    }
    
    public void check(Animal animal) {
        super.check(animal);
        ((Cat) animal).meow(); // cat specific code
    }
    
    public static void main(String[] args) {
        Cat[] cats = new Cat[] {new Cat("Nyan Cat")};
        Vet<Cat> catVet = new CatVet("Dr. Nick");
        catVet.check(cats);
    }
    
}
